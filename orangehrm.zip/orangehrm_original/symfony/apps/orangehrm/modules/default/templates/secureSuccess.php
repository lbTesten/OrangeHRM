<div class="box">    
      
    
<div class="message warning">
    <?php echo __(CommonMessages::CREDENTIALS_REQUIRED) ?> 
</div>
        <?php include_partial('global/flash_messages'); ?>
        
</div>